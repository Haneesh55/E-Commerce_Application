package com.cg.ecom.exceptions;

public class ProductSupplierNotAvailableException extends RuntimeException{


	private static final long serialVersionUID = 1L;

	public ProductSupplierNotAvailableException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductSupplierNotAvailableException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
